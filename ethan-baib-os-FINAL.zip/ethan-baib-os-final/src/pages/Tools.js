export { Tools as default } from './OtherPages'
