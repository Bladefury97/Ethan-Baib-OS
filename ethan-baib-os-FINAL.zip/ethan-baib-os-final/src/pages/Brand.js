export { Brand as default } from './OtherPages'
