export { Social as default } from './OtherPages'
