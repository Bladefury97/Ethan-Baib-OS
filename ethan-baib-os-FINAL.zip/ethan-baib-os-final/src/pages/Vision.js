export { Vision as default } from './OtherPages'
